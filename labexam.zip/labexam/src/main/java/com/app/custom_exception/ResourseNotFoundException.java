package com.app.custom_exception;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
public class ResourseNotFoundException extends RuntimeException{
	private String msg;
	public ResourseNotFoundException(String msg){
		super(msg);
	}
}
