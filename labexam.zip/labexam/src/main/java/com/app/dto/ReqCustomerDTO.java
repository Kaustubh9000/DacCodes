package com.app.dto;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ReqCustomerDTO {
	private String name;
	private String email;
	private String password;
	private String gender;
	private String address;
}
