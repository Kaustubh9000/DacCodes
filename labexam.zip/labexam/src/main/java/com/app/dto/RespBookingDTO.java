package com.app.dto;

import java.time.LocalDate;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor

public class RespBookingDTO {
	private Long id;
	private LocalDate pickupDate;
	private LocalDate dropDate;
	private String address;
	private Double price;
}
