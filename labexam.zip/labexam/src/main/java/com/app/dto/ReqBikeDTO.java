package com.app.dto;


import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ReqBikeDTO {
	private String name;
	private String model;
	private String companyName;
}
