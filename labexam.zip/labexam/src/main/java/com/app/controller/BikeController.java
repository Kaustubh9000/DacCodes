package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.dto.ReqBikeDTO;
import com.app.dto.ReqBookingDTO;
import com.app.dto.RespBookingDTO;
import com.app.entities.BookingEntity;
import com.app.service.BikeService;

@RestController
@RequestMapping("/bikes")
public class BikeController {

	@Autowired
	private BikeService bikeService;
	
	@PostMapping
	public ResponseEntity<?> addBike(@RequestBody ReqBikeDTO bike){
		return ResponseEntity.status(HttpStatus.CREATED).body(bikeService.saveBike(bike));
	}
	
	@PostMapping("/book")
	public ResponseEntity<?> bookBike(@RequestBody ReqBookingDTO booking){
		RespBookingDTO book = bikeService.bookBike(booking);
		if(book != null) {
			return ResponseEntity.ok(book);
		}
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to book the Bike");
	}
}
