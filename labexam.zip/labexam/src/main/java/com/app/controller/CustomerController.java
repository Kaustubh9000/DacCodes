package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.dto.ReqCustomerDTO;
import com.app.service.CustomerService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/customers")
@Slf4j
public class CustomerController {
	@Autowired
	private CustomerService custService;
	
	@PostMapping
	public ResponseEntity<?> addCustomer(@RequestBody ReqCustomerDTO cust ){
		log.info("Called Add Customer Method :" + cust);
		return ResponseEntity.status(HttpStatus.CREATED).body(custService.saveCustomer(cust));
	}
	
	@DeleteMapping("/{custId}")
	public ResponseEntity<?> deleteCustomer(@PathVariable Long custId) {
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(custService.deleteCustomer(custId));
	}
	
}
