package com.app.entities;

import java.time.LocalDate;

import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "booking_details")
@Getter
@Setter
@ToString(exclude = {"customer", "bike"})
@NoArgsConstructor
@AllArgsConstructor
public class BookingEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "b_id")
	private Long id;
	
	private LocalDate pickupDate;
	private LocalDate dropDate;
	private Double price;
	@Column(length = 255)
	private String address;
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	private CustomerEntity customer;
	@ManyToOne
	@JoinColumn(name = "bike_id")
	private BikeEntity bike;
	
	
}
