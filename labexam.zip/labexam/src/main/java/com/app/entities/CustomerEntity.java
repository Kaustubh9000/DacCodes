package com.app.entities;

import java.util.List;

import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "customers")
@Getter
@Setter
@ToString(exclude = "bookings")
@NoArgsConstructor
@AllArgsConstructor
public class CustomerEntity{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "u_id")
	private Long id;
	@Column(length = 50)
	private String name;
	@Column(length = 100)
	private String email;
	@Column(nullable = false)
	private String password;
	@Column(length = 10)
	private String gender;
	@Column(length = 100)
	private String address;
	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<BookingEntity> bookings;
	
}
