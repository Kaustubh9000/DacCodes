package com.app.entities;

public enum BikeStatus {
	AVAILABLE, NOT_AVAILABLE
}
