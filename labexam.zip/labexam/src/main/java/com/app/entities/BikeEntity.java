package com.app.entities;

import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.*;

@Entity
@Table(name = "bike_details")
@Getter
@Setter
@ToString(exclude = "bookings")
@NoArgsConstructor
@AllArgsConstructor
public class BikeEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bike_id")
	private Long id;
	@Column(length = 50)
	private String name;
	@Column(length = 50)
	private String model;
	@Column(length = 50)
	private String companyName;
	@Enumerated(EnumType.STRING)
	private BikeStatus status;
	@OneToMany(mappedBy = "bike",cascade = CascadeType.ALL, orphanRemoval = true)
	private List<BookingEntity> bookings;
	
}
