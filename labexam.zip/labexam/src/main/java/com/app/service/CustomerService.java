package com.app.service;

import com.app.dto.ReqCustomerDTO;
import com.app.dto.ResponseApi;
import com.app.entities.CustomerEntity;

public interface CustomerService {
	ReqCustomerDTO saveCustomer(ReqCustomerDTO cust);
	ResponseApi deleteCustomer(Long custId);
}
