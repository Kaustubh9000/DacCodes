package com.app.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exception.ResourseNotFoundException;
import com.app.dto.RespBookingDTO;
import com.app.dto.ResponseApi;
import com.app.entities.BikeStatus;
import com.app.entities.BookingEntity;
import com.app.repo.BookingRepository;

@Service
@Transactional
public class BookingServiceImpl implements BookingService{

	@Autowired
	private BookingRepository bookingRepo;
	@Autowired
	private ModelMapper mapper;
	
	@Override
	public List<RespBookingDTO> showAllBookings() {
		return bookingRepo.findAll().stream()
			.map(book -> mapper.map(book, RespBookingDTO.class))
			.collect(Collectors.toList());
	}

	@Override
	public ResponseApi deleteBikeRide(Long bookingId) {
		BookingEntity oldBooking= bookingRepo.findById(bookingId).orElseThrow(()->new ResourseNotFoundException("Invalid Booking Id !"));
		oldBooking.getBike().setStatus(BikeStatus.AVAILABLE);
		bookingRepo.delete(oldBooking);
		return new ResponseApi("Booking Deleted !");
	}
	
}
