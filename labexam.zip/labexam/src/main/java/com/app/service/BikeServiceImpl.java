package com.app.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exception.ResourseNotFoundException;
import com.app.dto.ReqBikeDTO;
import com.app.dto.ReqBookingDTO;
import com.app.dto.RespBookingDTO;
import com.app.dto.ResponseApi;
import com.app.entities.BikeEntity;
import com.app.entities.BikeStatus;
import com.app.entities.BookingEntity;
import com.app.entities.CustomerEntity;
import com.app.repo.BikeRepository;
import com.app.repo.BookingRepository;
import com.app.repo.CustomerRepository;

@Service
@Transactional
public class BikeServiceImpl implements BikeService{
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private BikeRepository bikeRepo;
	
	@Autowired 
	private CustomerRepository custRepo;

	@Autowired
	private BookingRepository bookingRepo;
	
	@Override
	public ReqBikeDTO saveBike(ReqBikeDTO bike) {
		BikeEntity newBike = mapper.map(bike, BikeEntity.class);
		newBike.setStatus(BikeStatus.AVAILABLE);
		return mapper.map(bikeRepo.save(newBike), ReqBikeDTO.class);
	}

	@Override
	public RespBookingDTO bookBike(ReqBookingDTO booking) {
		CustomerEntity cust = custRepo.findById(booking.getCustId()).orElseThrow(()->new ResourseNotFoundException("Invalid Customer Id !"));
		BikeEntity bike = bikeRepo.findById(booking.getBikeId()).orElseThrow(()->new ResourseNotFoundException("Invalid Bike Id !"));
		if(bike.getStatus().equals(BikeStatus.NOT_AVAILABLE)) {
			throw new ResourseNotFoundException("Bike Not Available !");
		}
		bike.setStatus(BikeStatus.NOT_AVAILABLE);
		BookingEntity newBooking = mapper.map(booking, BookingEntity.class);
		newBooking.setBike(bike);
		newBooking.setCustomer(cust);
		
		return mapper.map(bookingRepo.save(newBooking), RespBookingDTO.class);
	}
	

}
