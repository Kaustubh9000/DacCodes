package com.app.service;

import java.util.List;

import com.app.dto.RespBookingDTO;
import com.app.dto.ResponseApi;

public interface BookingService {
	List<RespBookingDTO> showAllBookings();
	ResponseApi deleteBikeRide(Long bookingId);
}
