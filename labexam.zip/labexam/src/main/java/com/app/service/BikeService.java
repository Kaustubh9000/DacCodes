package com.app.service;

import com.app.dto.ReqBikeDTO;
import com.app.dto.ReqBookingDTO;
import com.app.dto.RespBookingDTO;
import com.app.dto.ResponseApi;
import com.app.entities.BookingEntity;

public interface BikeService {
	ReqBikeDTO saveBike(ReqBikeDTO bike);
	RespBookingDTO bookBike(ReqBookingDTO booking);
}
