package com.app.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exception.ResourseNotFoundException;
import com.app.dto.ReqCustomerDTO;
import com.app.dto.ResponseApi;
import com.app.entities.BikeStatus;
import com.app.entities.CustomerEntity;
import com.app.repo.CustomerRepository;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private CustomerRepository custRepo;
	
	@Override
	public ReqCustomerDTO saveCustomer(ReqCustomerDTO cust) {
		
		return mapper.map(custRepo.save(mapper.map(cust, CustomerEntity.class)), ReqCustomerDTO.class);
	}

	@Override
	public ResponseApi deleteCustomer(Long custId) {
		CustomerEntity customer = custRepo.findById(custId).orElseThrow(()->new ResourseNotFoundException("Invalid Customer Id !"));
		customer.getBookings().forEach(booking-> booking.getBike().setStatus(BikeStatus.AVAILABLE));
		custRepo.delete(customer);
		return new ResponseApi("Customer id:"+customer.getId()+" deleted");
	}

}
