package com.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entities.BikeEntity;

public interface BikeRepository extends JpaRepository<BikeEntity, Long>{

}
