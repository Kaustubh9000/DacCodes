package com.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entities.CustomerEntity;

public interface CustomerRepository extends JpaRepository<CustomerEntity, Long> {
	
}
